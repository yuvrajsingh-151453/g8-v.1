package com.ordermanagement.gp8.order.utility;

public enum OrderStatus {
	ORDER_PLACED,
	PACKING,
	DISPATCHED,
	DELIVERED
}
