package com.ordermanagement.gp8.order.exception;


@SuppressWarnings("serial")
public class OrderException extends Exception{
	public OrderException(String message) {
		super(message);
	}
}
