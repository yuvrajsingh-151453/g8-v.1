package com.ordermanagement.gp8.order;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ordermanagement.gp8.order.dto.OrderDTO;
import com.ordermanagement.gp8.order.entity.Order;
import com.ordermanagement.gp8.order.exception.OrderException;
import com.ordermanagement.gp8.order.repository.OrderRepository;
import com.ordermanagement.gp8.order.repository.ProductsOrderedRepository;
import com.ordermanagement.gp8.order.service.OrderServiceImpl;

import jdk.jshell.spi.ExecutionControl.UserException;

@RunWith(SpringRunner.class)
@ContextConfiguration
public class OrderMsApplicationTests {

//	@Test
//	public void contextLoads() {
//	}

	@Mock
	OrderRepository orderRepository;

	@InjectMocks
	OrderServiceImpl orderService = new OrderServiceImpl();

	@Mock
	ProductsOrderedRepository productsOrderedRepo;


	@Test
	public void orderValidTest() throws UserException, OrderException {
		List<Order> orderList = new ArrayList<Order>();

		Order orderEntity = new Order();
		orderEntity.setOrderId("1");
		orderEntity.setBuyerId("B101");
		orderEntity.setAmount((float) 1000.0);
		orderEntity.setAddress("KUPT");
		
		orderEntity.setStatus("ORDERPLACED");

		orderList.add(orderEntity);
//
//		Mockito.when(orderRepository.findAll()).thenReturn(orderList);
//
//		List<OrderDTO> reProduct = orderService.getAllOrders();
//
//		Assertions.assertEquals(reProduct.isEmpty(), orderList.isEmpty());

	}

	@Test
	public void orderInvalidTest() throws UserException, OrderException {
		List<Order> orderList = new ArrayList<Order>();

		Order orderEntity = new Order();
		
		orderEntity.setOrderId("20");
		orderEntity.setBuyerId("B101");
		orderEntity.setAmount((float) 1000.0);
		orderEntity.setAddress("KUPT");
		
		orderEntity.setStatus("ORDERPLACED");

		
		Optional opt = Optional.of(orderEntity);// Valid

		Optional opt1 = Optional.empty();// Invalid
		

		Mockito.when(orderRepository.findById(Mockito.anyString())).thenReturn(opt1);

//	     Mockito.when(productrepo.findAll()).thenReturn(productList);

		List<OrderDTO> reProduct = orderService.getAllOrders();
//	          System.out.println(reProduct.get(0));
		Assertions.assertEquals(reProduct.isEmpty(), orderList.isEmpty());
	}
}
