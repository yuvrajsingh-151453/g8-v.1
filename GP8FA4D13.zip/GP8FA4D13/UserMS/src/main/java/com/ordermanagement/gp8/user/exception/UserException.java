package com.ordermanagement.gp8.user.exception;

@SuppressWarnings("serial")
public class UserException extends Exception {
	
	public UserException(String message) {
		super(message);
	}

}
