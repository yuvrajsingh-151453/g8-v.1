package com.oms.user;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ordermanagement.gp8.user.dto.BuyerDTO;
import com.ordermanagement.gp8.user.dto.SellerDTO;
import com.ordermanagement.gp8.user.entity.Buyer;
import com.ordermanagement.gp8.user.entity.Seller;
import com.ordermanagement.gp8.user.exception.UserException;
import com.ordermanagement.gp8.user.repository.BuyerRepository;
import com.ordermanagement.gp8.user.repository.SellerRepository;
import com.ordermanagement.gp8.user.service.BuyerServiceImpl;
import com.ordermanagement.gp8.user.service.SellerServiceImpl;

@RunWith(SpringRunner.class)
@ContextConfiguration
public class UserMsApplicationTests {

//	@Test
//	public void contextLoads() {
//	}
	@Mock
	BuyerRepository buyerRepository;
	@Mock
	SellerRepository sellerRepository;
	@InjectMocks
	BuyerServiceImpl buyerService = new BuyerServiceImpl();
	@InjectMocks
	SellerServiceImpl sellerService = new SellerServiceImpl();

	// Test for valid data
	@Test
	public void authenticateBuyerValid() throws UserException {
		List<Buyer> buyerList = new ArrayList<Buyer>();

		Buyer buyerEntity = new Buyer();
		buyerEntity.setBuyerId("B100");
		buyerEntity.setEmail("Yuvraj.1223@gmail.com");
		buyerEntity.setName("Yuvraj");
		buyerEntity.setPassword("Hello@123");
		buyerEntity.setPhoneNumber("9009009001");

		buyerList.add(buyerEntity);

		Mockito.when(buyerRepository.findAll()).thenReturn(buyerList);
		List<BuyerDTO> rePlans = buyerService.getAllBuyers();
		Assertions.assertEquals(rePlans.isEmpty(), buyerList.isEmpty());
	}

	// Test for Invalid data
	@Test
	public void authenticateBuyerInvalid() throws UserException {
		List<Buyer> buyerList = new ArrayList<Buyer>();

		Buyer buyerEntity = new Buyer();
//		buyerEntity.setBuyerId("B10");
//		buyerEntity.setEmail("yuvraj@gmail.com");
//		buyerEntity.setName("Yuvraj");
//		buyerEntity.setPassword("hi@123");
//		buyerEntity.setPhoneNumber("909009001");

		buyerEntity.setBuyerId("B10");
		buyerEntity.setEmail("Yuvraj");
		buyerEntity.setName("Yuvraj");
		buyerEntity.setPassword("hi@123");
		buyerEntity.setPhoneNumber("909009001");

		buyerList.add(buyerEntity);
		Optional opt = Optional.of(buyerEntity);// Valid

		Optional opt1 = Optional.empty();// Invalid

		Mockito.when(buyerRepository.findById(Mockito.anyString())).thenReturn(opt1);

//		Mockito.when(buyerRepository.findAll()).thenReturn(buyerList);
		List<BuyerDTO> rePlans = buyerService.getAllBuyers();
		Assertions.assertEquals(rePlans.isEmpty(), buyerList.isEmpty());
	}

	@Test
	public void authenticateSellerValid() throws UserException {
		List<Seller> sellerList = new ArrayList<Seller>();

		Seller sellerEntity = new Seller();
		sellerEntity.setSellerId("1");
		sellerEntity.setEmail("Kushal@gmail.com");
		sellerEntity.setName("Kushal");
		sellerEntity.setPassword("hii@123");
		sellerEntity.setPhoneNumber("7007007001");
		;

		sellerList.add(sellerEntity);

		Mockito.when(sellerRepository.findAll()).thenReturn(sellerList);
		List<SellerDTO> rePlans = sellerService.getAllSellers();
		Assertions.assertEquals(rePlans.isEmpty(), sellerList.isEmpty());
	}

	@Test
	public void authenticateSellerInValid() throws UserException {
		List<Seller> sellerList = new ArrayList<Seller>();

		Seller sellerEntity = new Seller();
		sellerEntity.setSellerId("123");
		sellerEntity.setEmail("Avinash@gmail.com");
		sellerEntity.setName("Avi");
		sellerEntity.setPassword("avi@123");
		sellerEntity.setPhoneNumber("7007007001");
		;

		Optional opt = Optional.of(sellerEntity);// Valid

		Optional opt1 = Optional.empty();// Invalid

		Mockito.when(buyerRepository.findById(Mockito.anyString())).thenReturn(opt);

		Mockito.when(sellerRepository.findAll()).thenReturn(sellerList);
		List<SellerDTO> rePlans = sellerService.getAllSellers();
		Assertions.assertEquals(rePlans.isEmpty(), sellerList.isEmpty());
	}

}
