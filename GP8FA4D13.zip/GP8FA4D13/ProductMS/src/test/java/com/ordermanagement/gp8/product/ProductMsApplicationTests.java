package com.ordermanagement.gp8.product;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import com.ordermanagement.gp8.product.dto.ProductDTO;
import com.ordermanagement.gp8.product.entity.Product;
import com.ordermanagement.gp8.product.exception.ProductException;
import com.ordermanagement.gp8.product.repository.ProductRepository;
import com.ordermanagement.gp8.product.repository.SubscribedProductRepository;
import com.ordermanagement.gp8.product.service.ProductServiceImpl;

import jdk.jshell.spi.ExecutionControl.UserException;


@ContextConfiguration
public class ProductMsApplicationTests {

//	@Test
//	public void contextLoads() {
//	}

	@Mock
	ProductRepository productrepo;

	@InjectMocks
	ProductServiceImpl productService = new ProductServiceImpl();

	@Mock
	SubscribedProductRepository subscribedprodrepo;



	@Test
	public void productValidTest() throws UserException, ProductException {
		List<Product> productList = new ArrayList<Product>();

		Product productEntity = new Product();
		productEntity.setProdId("P101");
		productEntity.setProductName("mobile");
		productEntity.setPrice((float) 500.0);
		productEntity.setStock(10000);
		productEntity.setDescription("vivo mobile");
		productEntity.setImage("https://mk.media-flipkart.com/images/I/jRzGyD52UJL.jpeg");
		productEntity.setSellerId("1");
		productEntity.setCategory("smart phone");
		productEntity.setCategory("one plus");
		productEntity.setProductRating((float) 4);

		productList.add(productEntity);

		Mockito.when(productrepo.findAll()).thenReturn(productList);

		List<ProductDTO> reProduct = productService.getAllProducts();

		Assertions.assertEquals(reProduct.isEmpty(), productList.isEmpty());

	}

	@Test
	public void productinvalidtest() throws UserException, ProductException {
		List<Product> productList = new ArrayList<Product>();

		Product productEntity = new Product();
		productEntity.setProdId("P101");
		productEntity.setProductName("oopo");
		productEntity.setPrice((float) 5000.0);
		productEntity.setStock(5);
		productEntity.setDescription("oppo mobile");
		productEntity.setImage("imagr.png");
		productEntity.setSellerId("2");
		productEntity.setCategory("ads");
		productEntity.setCategory("ads");
		productEntity.setProductRating((float) 3);

		Optional opt = Optional.of(productEntity);// Valid

		Optional opt1 = Optional.empty();// Invalid

		Mockito.when(productrepo.findById(Mockito.anyString())).thenReturn(opt1);

//	     Mockito.when(productrepo.findAll()).thenReturn(productList);

		List<ProductDTO> reProduct = productService.getAllProducts();
//	          System.out.println(reProduct.get(0));
		Assertions.assertEquals(reProduct.isEmpty(), productList.isEmpty());
	}

	
}
