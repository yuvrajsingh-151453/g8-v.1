package com.ordermanagement.gp8.product.exception;

@SuppressWarnings("serial")
public class ProductException extends Exception {
	
	public ProductException(String message) {
		super(message);
	}

}
